import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HisSchemaConfig }  from './his-schema-config.entity';
import { HisConfigService } from './his-config.service';
import { RedisProvider }    from '../../../common/redis/redis.provider';

/**
 * HisConfigModule
 *
 * Provides HisConfigService globally — imported by HisModule and
 * referenced in the vendor webhook handler (LicensingModule).
 *
 * No circular dependency risk: this module only depends on TypeORM
 * and Redis, not on HisModule or LoyaltyModule.
 */
@Module({
  imports: [TypeOrmModule.forFeature([HisSchemaConfig])],
  providers: [HisConfigService, RedisProvider],
  exports: [HisConfigService],
})
export class HisConfigModule {}
