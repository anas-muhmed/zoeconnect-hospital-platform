import {
  Entity, PrimaryGeneratedColumn, Column, UpdateDateColumn, Index,
} from 'typeorm';

/**
 * HisSchemaConfig — stores per-hospital Oracle table/column name mappings.
 *
 * Populated by the vendor portal via the HIS_CONFIG_UPDATE webhook event.
 * Seeded with defaults by migration 010 so queries work out-of-the-box
 * with the placeholder names until the vendor admin configures real ones.
 *
 * config_key examples:
 *   "patient.table"        → "PAT_MASTER"   (or hospital's real table name)
 *   "billing.col.billId"   → "BILL_NO"
 *   "billing.status.finalised" → "FINALISED"
 */
@Entity('his_schema_configs')
@Index('uq_his_schema_configs_key', ['configKey'], { unique: true })
export class HisSchemaConfig {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  /** Internal dot-notation key — e.g. "billing.table", "patient.col.mrn" */
  @Column({ name: 'config_key', type: 'varchar', length: 120 })
  configKey: string;

  /** Resolved Oracle identifier — e.g. "BILL_MASTER", "UHID" */
  @Column({ name: 'config_value', type: 'varchar', length: 255 })
  configValue: string;

  @UpdateDateColumn({ name: 'updated_at', type: 'timestamptz' })
  updatedAt: Date;
}
