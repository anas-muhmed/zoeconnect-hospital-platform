import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { InjectRedis } from '../../../common/redis/redis.provider';
import type { Redis } from 'ioredis';
import { HisSchemaConfig } from './his-schema-config.entity';

/** Redis cache key for the full config map */
const REDIS_KEY   = 'his:schema:config';
/** TTL: 1 hour — refreshed on every push from vendor portal */
const CACHE_TTL_S = 3600;

/**
 * HisConfigService
 *
 * Provides a single method — `getConfig()` — that returns the full
 * key→value map of Oracle identifiers for this HDSP instance.
 *
 * Cache strategy:
 *   1. Hot path:   Redis GET   (< 1 ms)
 *   2. Cold path:  PostgreSQL  (all rows, ~1–5 ms) → write to Redis
 *   3. Invalidate: call invalidateCache() after a HIS_CONFIG_UPDATE webhook
 *
 * Usage in HIS services:
 *   const cfg = await this.hisConfig.getConfig();
 *   const sql = `SELECT ... FROM ${cfg['billing.table']} b WHERE b.${cfg['billing.col.mrn']} = :mrn`;
 */
@Injectable()
export class HisConfigService implements OnModuleInit {
  private readonly logger = new Logger(HisConfigService.name);

  constructor(
    @InjectRepository(HisSchemaConfig)
    private readonly repo: Repository<HisSchemaConfig>,
    @InjectRedis() private readonly redis: Redis,
  ) {}

  /** Warm the cache on startup so first request is always fast */
  async onModuleInit() {
    try {
      await this.getConfig();
      this.logger.log('HIS schema config loaded into Redis cache');
    } catch (err) {
      this.logger.warn(`Failed to pre-warm HIS schema config: ${(err as Error).message}`);
    }
  }

  /**
   * Returns the full config map: { 'billing.table': 'BILL_MASTER', ... }
   * Redis-cached; falls back to DB on cache miss.
   */
  async getConfig(): Promise<Record<string, string>> {
    // ── Hot path: Redis ───────────────────────────────────────────────────
    const cached = await this.redis.get(REDIS_KEY);
    if (cached) {
      return JSON.parse(cached) as Record<string, string>;
    }

    // ── Cold path: DB ─────────────────────────────────────────────────────
    return this.loadFromDb();
  }

  /**
   * Receives the full key→value map from a vendor webhook push,
   * upserts every entry into the DB, then refreshes the Redis cache.
   */
  async applyWebhookUpdate(updates: Record<string, string>): Promise<void> {
    const entries = Object.entries(updates);
    if (!entries.length) return;

    this.logger.log(`HIS_CONFIG_UPDATE: applying ${entries.length} key(s)`);

    // Upsert each key (conflict on config_key → update config_value + updated_at)
    for (const [key, value] of entries) {
      await this.repo.upsert(
        { configKey: key, configValue: String(value).toUpperCase() },
        { conflictPaths: ['configKey'] },
      );
    }

    // Refresh Redis cache immediately
    await this.loadFromDb();
    this.logger.log('HIS schema config cache refreshed after webhook update');
  }

  /** Drop the Redis key so the next getConfig() re-reads from DB */
  async invalidateCache(): Promise<void> {
    await this.redis.del(REDIS_KEY);
    this.logger.debug('HIS schema config cache invalidated');
  }

  // ── Private ──────────────────────────────────────────────────────────────

  private async loadFromDb(): Promise<Record<string, string>> {
    const rows = await this.repo.find();
    const map: Record<string, string> = {};
    for (const row of rows) {
      map[row.configKey] = row.configValue;
    }
    await this.redis.setex(REDIS_KEY, CACHE_TTL_S, JSON.stringify(map));
    return map;
  }
}
