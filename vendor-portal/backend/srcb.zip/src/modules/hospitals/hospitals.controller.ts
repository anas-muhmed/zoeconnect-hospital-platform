import {
  Controller, Get, Post, Patch, Body, Param,
  Query, UseGuards, Request, HttpCode,
} from '@nestjs/common';
import { HospitalsService, ApproveRequestDto, RevokeDto } from './hospitals.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Public } from '../auth/decorators/public.decorator';

@Controller()
export class HospitalsController {
  constructor(private readonly svc: HospitalsService) {}

  // ── Public: called by HDSP instances ─────────────────────────────────────────

  /** POST /api/hospitals/register — called by HDSP on first boot */
  @Public()
  @Post('hospitals/register')
  register(@Body() body: {
    hospitalName: string; hospitalCode: string;
    publicIp: string; publicPort: number;
    webhookUrl: string; machineFingerprint: string;
  }) {
    return this.svc.register(body);
  }

  /** POST /api/requests — hospital submits a license request */
  @Public()
  @Post('requests')
  createRequest(
    @Body() body: {
      instanceToken:      string;
      requestedModules:   string[];
      currentModules:     string[];
      remarks?:           string;
      machineFingerprint: string;
      isTrial:            boolean;
      expiresAt?:         string | null;
    },
  ) {
    const { instanceToken, ...rest } = body;
    return this.svc.createRequest(instanceToken, rest);
  }

  // ── Vendor-authenticated endpoints ────────────────────────────────────────────

  /** GET /api/hospitals */
  @UseGuards(JwtAuthGuard)
  @Get('hospitals')
  findAll() {
    return this.svc.findAll();
  }

  /** GET /api/hospitals/:id */
  @UseGuards(JwtAuthGuard)
  @Get('hospitals/:id')
  findOne(@Param('id') id: string) {
    return this.svc.findOne(id);
  }

  /** PATCH /api/hospitals/:id/notes */
  @UseGuards(JwtAuthGuard)
  @Patch('hospitals/:id/notes')
  updateNotes(@Param('id') id: string, @Body('notes') notes: string) {
    return this.svc.updateNotes(id, notes);
  }

  /** PATCH /api/hospitals/:id/suspend */
  @UseGuards(JwtAuthGuard)
  @Patch('hospitals/:id/suspend')
  suspend(@Param('id') id: string) {
    return this.svc.suspend(id);
  }

  /** PATCH /api/hospitals/:id/activate */
  @UseGuards(JwtAuthGuard)
  @Patch('hospitals/:id/activate')
  activate(@Param('id') id: string) {
    return this.svc.activate(id);
  }

  /** PATCH /api/hospitals/:id/extend-trial */
  @UseGuards(JwtAuthGuard)
  @Patch('hospitals/:id/extend-trial')
  extendTrial(
    @Param('id') id: string,
    @Body() body: { newExpiresAt: string; reason: string },
    @Request() req: any,
  ) {
    return this.svc.extendTrial(id, body.newExpiresAt, body.reason, req.user.id);
  }

  /** POST /api/hospitals/:id/revoke */
  @UseGuards(JwtAuthGuard)
  @Post('hospitals/:id/revoke')
  @HttpCode(200)
  revoke(@Param('id') id: string, @Body() dto: RevokeDto, @Request() req: any) {
    return this.svc.revokeHospital(id, dto, req.user.id);
  }

  /** GET /api/hospitals/:id/licenses */
  @UseGuards(JwtAuthGuard)
  @Get('hospitals/:id/licenses')
  getHospitalLicenses(@Param('id') id: string) {
    return this.svc.findHospitalLicenses(id);
  }

  // ── Requests ──────────────────────────────────────────────────────────────────

  /** GET /api/requests?status=PENDING */
  @UseGuards(JwtAuthGuard)
  @Get('requests')
  findAllRequests(@Query('status') status?: string) {
    return this.svc.findAllRequests(status);
  }

  /** GET /api/requests/:id */
  @UseGuards(JwtAuthGuard)
  @Get('requests/:id')
  findRequest(@Param('id') id: string) {
    return this.svc.findRequest(id);
  }

  /** POST /api/requests/:id/approve */
  @UseGuards(JwtAuthGuard)
  @Post('requests/:id/approve')
  @HttpCode(200)
  approveRequest(
    @Param('id') id: string,
    @Body() dto: ApproveRequestDto,
    @Request() req: any,
  ) {
    return this.svc.approveRequest(id, dto, req.user.id);
  }

  /** POST /api/requests/:id/reject */
  @UseGuards(JwtAuthGuard)
  @Post('requests/:id/reject')
  @HttpCode(200)
  rejectRequest(
    @Param('id') id: string,
    @Body('reason') reason: string,
    @Request() req: any,
  ) {
    return this.svc.rejectRequest(id, reason, req.user.id);
  }

  // ── Licenses ──────────────────────────────────────────────────────────────────

  /** GET /api/licenses — active only */
  @UseGuards(JwtAuthGuard)
  @Get('licenses')
  findActiveLicenses() {
    return this.svc.findActiveLicenses();
  }

  /** GET /api/licenses/history — all licenses (active + revoked + expired) */
  @UseGuards(JwtAuthGuard)
  @Get('licenses/history')
  findAllLicenses() {
    return this.svc.findAllLicenses();
  }

  /** GET /api/revocations — all revocation events with webhook status */
  @UseGuards(JwtAuthGuard)
  @Get('revocations')
  findAllRevocations() {
    return this.svc.findAllRevocations();
  }

  // ── HIS Schema Config ────────────────────────────────────────────────────

  /** GET /api/hospitals/:id/his-config — full config list with defaults */
  @UseGuards(JwtAuthGuard)
  @Get('hospitals/:id/his-config')
  getHisConfig(@Param('id') id: string) {
    return this.svc.getHisConfig(id);
  }

  /** PATCH /api/hospitals/:id/his-config — save one or more key/value pairs */
  @UseGuards(JwtAuthGuard)
  @Patch('hospitals/:id/his-config')
  updateHisConfig(
    @Param('id') id: string,
    @Body() body: { updates: Array<{ configKey: string; configValue: string }> },
  ) {
    return this.svc.updateHisConfig(id, body.updates);
  }

  /** POST /api/hospitals/:id/push-his-config — deliver config to HDSP via webhook */
  @UseGuards(JwtAuthGuard)
  @Post('hospitals/:id/push-his-config')
  @HttpCode(200)
  pushHisConfig(@Param('id') id: string) {
    return this.svc.pushHisConfig(id);
  }
}
