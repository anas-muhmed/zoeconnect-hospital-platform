import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, UpdateDateColumn, OneToMany,
} from 'typeorm';
import { LicenseRequest } from './license-request.entity';
import { IssuedLicense }  from './issued-license.entity';
import { RevocationEvent } from './revocation-event.entity';

export type HospitalStatus = 'PENDING' | 'ACTIVE' | 'SUSPENDED';

@Entity('hospitals')
export class Hospital {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'instance_token', type: 'varchar', length: 64, unique: true })
  instanceToken: string;

  @Column({ name: 'webhook_secret', type: 'varchar', length: 128 })
  webhookSecret: string;

  @Column({ name: 'hospital_name', type: 'varchar', length: 255 })
  hospitalName: string;

  @Column({ name: 'hospital_code', type: 'varchar', length: 64, unique: true })
  hospitalCode: string;

  @Column({ name: 'public_ip', type: 'varchar', length: 128 })
  publicIp: string;

  @Column({ name: 'public_port', type: 'int', default: 3000 })
  publicPort: number;

  @Column({ name: 'webhook_url', type: 'varchar', length: 512 })
  webhookUrl: string;

  @Column({ name: 'machine_fingerprint', type: 'varchar', length: 64 })
  machineFingerprint: string;

  @Column({ name: 'status', type: 'varchar', length: 32, default: 'ACTIVE' })
  status: HospitalStatus;

  @Column({ name: 'notes', type: 'text', nullable: true })
  notes: string | null;

  @Column({ name: 'last_webhook_at', type: 'timestamptz', nullable: true })
  lastWebhookAt: Date | null;

  @Column({ name: 'last_webhook_status', type: 'varchar', length: 32, nullable: true })
  lastWebhookStatus: 'OK' | 'FAILED' | null;

  @CreateDateColumn({ name: 'registered_at' })
  registeredAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  @OneToMany(() => LicenseRequest, (r) => r.hospital)
  requests: LicenseRequest[];

  @OneToMany(() => IssuedLicense, (l) => l.hospital)
  licenses: IssuedLicense[];

  @OneToMany(() => RevocationEvent, (e) => e.hospital)
  revocations: RevocationEvent[];
}
