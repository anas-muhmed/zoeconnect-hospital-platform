import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HospitalsController } from './hospitals.controller';
import { HospitalsService }    from './hospitals.service';
import { Hospital }            from './entities/hospital.entity';
import { LicenseRequest }      from './entities/license-request.entity';
import { IssuedLicense }       from './entities/issued-license.entity';
import { RevocationEvent }     from './entities/revocation-event.entity';
import { HisSchemaConfig }     from './entities/his-schema-config.entity';
import { SigningService }      from '../signing/signing.service';
import { WebhookService }      from '../webhook/webhook.service';
import { AuthModule }          from '../auth/auth.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Hospital, LicenseRequest, IssuedLicense, RevocationEvent, HisSchemaConfig]),
    AuthModule,
  ],
  controllers: [HospitalsController],
  providers:   [HospitalsService, SigningService, WebhookService],
  exports:     [HospitalsService],
})
export class HospitalsModule {}
