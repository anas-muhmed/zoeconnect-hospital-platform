/**
 * Default Oracle HIS schema placeholders.
 * These are the names used in code when no hospital-specific mapping exists.
 * The vendor admin replaces these with the real Oracle identifiers per hospital.
 */
export interface HisSchemaEntry {
  key: string;
  defaultValue: string;
  label: string;
  description: string;
  configType: 'TABLE' | 'COLUMN' | 'STATUS_VALUE';
  category: string;
}

export const HIS_SCHEMA_DEFAULTS: HisSchemaEntry[] = [
  // ── PATIENT ──────────────────────────────────────────────────────────────
  { key: 'patient.table',           defaultValue: 'PAT_MASTER',    label: 'Patient Table',               description: 'Main patient demographics table',                        configType: 'TABLE',        category: 'PATIENT' },
  { key: 'patient.col.mrn',         defaultValue: 'UHID',          label: 'MRN / UHID Column',           description: 'Unique patient identifier / MRN used across all tables',  configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.col.salutation',  defaultValue: 'SALUTATION',    label: 'Salutation Column',           description: 'Mr / Mrs / Dr prefix',                                   configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.col.firstName',   defaultValue: 'FIRST_NAME',    label: 'First Name Column',           description: '',                                                       configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.col.middleName',  defaultValue: 'MIDDLE_NAME',   label: 'Middle Name Column',          description: 'Nullable — used in NVL()',                               configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.col.lastName',    defaultValue: 'LAST_NAME',     label: 'Last Name Column',            description: '',                                                       configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.col.gender',      defaultValue: 'GENDER',        label: 'Gender Column',               description: 'Expected values: M / F / O',                             configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.col.dob',         defaultValue: 'DOB',           label: 'Date of Birth Column',        description: 'Used for birthday campaign trigger',                      configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.col.bloodGroup',  defaultValue: 'BLOOD_GROUP',   label: 'Blood Group Column',          description: '',                                                       configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.col.mobile',      defaultValue: 'MOBILE_NO',     label: 'Mobile Number Column',        description: 'Used for WhatsApp notifications',                         configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.col.email',       defaultValue: 'EMAIL_ID',      label: 'Email Column',                description: '',                                                       configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.col.address',     defaultValue: 'ADDRESS_LINE1', label: 'Address Column',              description: '',                                                       configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.col.city',        defaultValue: 'CITY',          label: 'City Column',                 description: '',                                                       configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.col.state',       defaultValue: 'STATE',         label: 'State Column',                description: '',                                                       configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.col.pinCode',     defaultValue: 'PIN_CODE',      label: 'PIN / ZIP Code Column',       description: '',                                                       configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.col.aadhaar',     defaultValue: 'AADHAAR_NO',    label: 'Aadhaar Column',              description: 'Only last 4 digits are read',                            configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.col.regDate',     defaultValue: 'REG_DATE',      label: 'Registration Date Column',    description: '',                                                       configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.col.status',      defaultValue: 'STATUS',        label: 'Patient Status Column',       description: 'Column that holds active/inactive flag',                  configType: 'COLUMN',       category: 'PATIENT' },
  { key: 'patient.status.active',   defaultValue: 'A',             label: 'Active Status Value',         description: 'Value in status column meaning the patient is active',    configType: 'STATUS_VALUE', category: 'PATIENT' },

  // ── BILLING ───────────────────────────────────────────────────────────────
  { key: 'billing.table',              defaultValue: 'BILL_MASTER',  label: 'Billing Header Table',          description: 'One row per bill/invoice',                                                      configType: 'TABLE',        category: 'BILLING' },
  { key: 'billing.col.billId',         defaultValue: 'BILL_NO',      label: 'Bill ID Column',                description: '⚡ Critical — stored as loyalty transaction reference. Must be unique per bill.', configType: 'COLUMN',       category: 'BILLING' },
  { key: 'billing.col.mrn',            defaultValue: 'UHID',         label: 'Patient MRN Column (in bills)', description: 'Links bill to patient — must match patient.col.mrn',                             configType: 'COLUMN',       category: 'BILLING' },
  { key: 'billing.col.patientName',    defaultValue: 'PATIENT_NAME', label: 'Patient Name Column',           description: 'Fallback name if PAT_MASTER is unavailable',                                    configType: 'COLUMN',       category: 'BILLING' },
  { key: 'billing.col.visitId',        defaultValue: 'VISIT_ID',     label: 'Visit ID Column',               description: 'Linked visit number (nullable)',                                                 configType: 'COLUMN',       category: 'BILLING' },
  { key: 'billing.col.billDate',       defaultValue: 'BILL_DATE',    label: 'Bill Date Column',              description: '',                                                                               configType: 'COLUMN',       category: 'BILLING' },
  { key: 'billing.col.billType',       defaultValue: 'BILL_TYPE',    label: 'Bill Type Column',              description: 'OPD / IPD / PHARMACY etc.',                                                     configType: 'COLUMN',       category: 'BILLING' },
  { key: 'billing.col.totalAmount',    defaultValue: 'TOTAL_AMT',    label: 'Total Amount Column',           description: '⚡ Critical — loyalty points calculated from this value (1 pt per ₹100)',        configType: 'COLUMN',       category: 'BILLING' },
  { key: 'billing.col.paidAmount',     defaultValue: 'PAID_AMT',     label: 'Paid Amount Column',            description: '',                                                                               configType: 'COLUMN',       category: 'BILLING' },
  { key: 'billing.col.balanceAmount',  defaultValue: 'BALANCE_AMT',  label: 'Balance Amount Column',         description: '',                                                                               configType: 'COLUMN',       category: 'BILLING' },
  { key: 'billing.col.discountAmount', defaultValue: 'DISCOUNT_AMT', label: 'Discount Amount Column',        description: '',                                                                               configType: 'COLUMN',       category: 'BILLING' },
  { key: 'billing.col.status',         defaultValue: 'BILL_STATUS',  label: 'Bill Status Column',            description: '⚡ Critical — used to filter only finalised bills',                              configType: 'COLUMN',       category: 'BILLING' },
  { key: 'billing.col.doctorCode',     defaultValue: 'DOCTOR_CODE',  label: 'Doctor Code Column',            description: '',                                                                               configType: 'COLUMN',       category: 'BILLING' },
  { key: 'billing.col.doctorName',     defaultValue: 'DOCTOR_NAME',  label: 'Doctor Name Column',            description: '',                                                                               configType: 'COLUMN',       category: 'BILLING' },
  { key: 'billing.col.deptCode',       defaultValue: 'DEPT_CODE',    label: 'Department Code Column',        description: '',                                                                               configType: 'COLUMN',       category: 'BILLING' },
  { key: 'billing.col.deptName',       defaultValue: 'DEPT_NAME',    label: 'Department Name Column',        description: '',                                                                               configType: 'COLUMN',       category: 'BILLING' },
  { key: 'billing.col.updatedAt',      defaultValue: 'UPDATED_AT',   label: 'Last Updated Column',           description: '⚡ Critical — sync cursor. Must be an indexed timestamp updated on every bill change. Common: LAST_UPDATED, MODIFIED_DATE, UPDATE_DATE', configType: 'COLUMN', category: 'BILLING' },
  { key: 'billing.status.finalised',   defaultValue: 'FINALISED',    label: 'Finalised Status Value',        description: '⚡ Critical — only bills with this status earn points. Common: F, FINAL, PAID, APPROVED', configType: 'STATUS_VALUE', category: 'BILLING' },
  { key: 'billing.status.cancelled',   defaultValue: 'CANCELLED',    label: 'Cancelled Status Value',        description: 'Bills with this status are excluded. Common: C, CANCEL, VOID, CAN',              configType: 'STATUS_VALUE', category: 'BILLING' },
  { key: 'billing.status.reversed',    defaultValue: 'REVERSED',     label: 'Reversed Status Value',         description: 'Bills with this status are excluded. Common: R, REV, REVERSE',                   configType: 'STATUS_VALUE', category: 'BILLING' },

  // ── BILL ITEMS ────────────────────────────────────────────────────────────
  { key: 'billItems.table',         defaultValue: 'BILL_ITEMS',  label: 'Bill Line Items Table',   description: 'One row per service/procedure in a bill',        configType: 'TABLE',  category: 'BILL_ITEMS' },
  { key: 'billItems.col.billId',    defaultValue: 'BILL_NO',     label: 'Bill ID Column',          description: 'FK linking items to bill header',                configType: 'COLUMN', category: 'BILL_ITEMS' },
  { key: 'billItems.col.itemCode',  defaultValue: 'ITEM_CODE',   label: 'Item / Service Code',     description: '',                                               configType: 'COLUMN', category: 'BILL_ITEMS' },
  { key: 'billItems.col.itemName',  defaultValue: 'ITEM_NAME',   label: 'Item / Service Name',     description: '',                                               configType: 'COLUMN', category: 'BILL_ITEMS' },
  { key: 'billItems.col.quantity',  defaultValue: 'QUANTITY',    label: 'Quantity Column',         description: '',                                               configType: 'COLUMN', category: 'BILL_ITEMS' },
  { key: 'billItems.col.unitPrice', defaultValue: 'UNIT_PRICE',  label: 'Unit Price Column',       description: '',                                               configType: 'COLUMN', category: 'BILL_ITEMS' },
  { key: 'billItems.col.amount',    defaultValue: 'AMOUNT',      label: 'Line Amount Column',      description: '',                                               configType: 'COLUMN', category: 'BILL_ITEMS' },
  { key: 'billItems.col.deptCode',  defaultValue: 'DEPT_CODE',   label: 'Department Code Column',  description: '',                                               configType: 'COLUMN', category: 'BILL_ITEMS' },
  { key: 'billItems.col.deptName',  defaultValue: 'DEPT_NAME',   label: 'Department Name Column',  description: '',                                               configType: 'COLUMN', category: 'BILL_ITEMS' },
  { key: 'billItems.col.serialNo',  defaultValue: 'SL_NO',       label: 'Serial / Sequence No.',   description: 'Used for ORDER BY on line items',                configType: 'COLUMN', category: 'BILL_ITEMS' },

  // ── VISIT ─────────────────────────────────────────────────────────────────
  { key: 'visit.table',              defaultValue: 'VISIT_MASTER',    label: 'Visit Table',               description: 'OPD / IPD visit records',            configType: 'TABLE',  category: 'VISIT' },
  { key: 'visit.col.visitId',        defaultValue: 'VISIT_ID',        label: 'Visit ID Column',           description: 'Unique visit identifier',             configType: 'COLUMN', category: 'VISIT' },
  { key: 'visit.col.mrn',            defaultValue: 'UHID',            label: 'Patient MRN Column',        description: 'Links visit to patient',              configType: 'COLUMN', category: 'VISIT' },
  { key: 'visit.col.visitDate',      defaultValue: 'VISIT_DATE',      label: 'Visit Date Column',         description: '',                                    configType: 'COLUMN', category: 'VISIT' },
  { key: 'visit.col.visitType',      defaultValue: 'VISIT_TYPE',      label: 'Visit Type Column',         description: 'OPD / IPD / EMERGENCY',              configType: 'COLUMN', category: 'VISIT' },
  { key: 'visit.col.admissionDate',  defaultValue: 'ADMISSION_DATE',  label: 'Admission Date Column',     description: 'IPD only — nullable',                 configType: 'COLUMN', category: 'VISIT' },
  { key: 'visit.col.dischargeDate',  defaultValue: 'DISCHARGE_DATE',  label: 'Discharge Date Column',     description: 'IPD only — nullable',                 configType: 'COLUMN', category: 'VISIT' },
  { key: 'visit.col.doctorCode',     defaultValue: 'DOCTOR_CODE',     label: 'Doctor Code Column',        description: '',                                    configType: 'COLUMN', category: 'VISIT' },
  { key: 'visit.col.doctorName',     defaultValue: 'DOCTOR_NAME',     label: 'Doctor Name Column',        description: '',                                    configType: 'COLUMN', category: 'VISIT' },
  { key: 'visit.col.deptCode',       defaultValue: 'DEPT_CODE',       label: 'Department Code Column',    description: '',                                    configType: 'COLUMN', category: 'VISIT' },
  { key: 'visit.col.deptName',       defaultValue: 'DEPT_NAME',       label: 'Department Name Column',    description: '',                                    configType: 'COLUMN', category: 'VISIT' },
  { key: 'visit.col.ward',           defaultValue: 'WARD_NAME',       label: 'Ward Name Column',          description: 'IPD only — nullable',                 configType: 'COLUMN', category: 'VISIT' },
  { key: 'visit.col.bed',            defaultValue: 'BED_NO',          label: 'Bed Number Column',         description: 'IPD only — nullable',                 configType: 'COLUMN', category: 'VISIT' },
  { key: 'visit.col.diagnosis',      defaultValue: 'DIAGNOSIS',       label: 'Diagnosis Column',          description: 'nullable',                            configType: 'COLUMN', category: 'VISIT' },
  { key: 'visit.col.status',         defaultValue: 'VISIT_STATUS',    label: 'Visit Status Column',       description: '',                                    configType: 'COLUMN', category: 'VISIT' },

  // ── DEPARTMENT ────────────────────────────────────────────────────────────
  { key: 'department.table',          defaultValue: 'DEPARTMENT_MASTER', label: 'Department Table',         description: 'Master list of hospital departments',          configType: 'TABLE',        category: 'DEPARTMENT' },
  { key: 'department.col.code',       defaultValue: 'DEPT_CODE',         label: 'Department Code Column',   description: '',                                             configType: 'COLUMN',       category: 'DEPARTMENT' },
  { key: 'department.col.name',       defaultValue: 'DEPT_NAME',         label: 'Department Name Column',   description: '',                                             configType: 'COLUMN',       category: 'DEPARTMENT' },
  { key: 'department.col.shortCode',  defaultValue: 'SHORT_CODE',        label: 'Short Code Column',        description: 'Abbreviated department code',                  configType: 'COLUMN',       category: 'DEPARTMENT' },
  { key: 'department.col.type',       defaultValue: 'DEPT_TYPE',         label: 'Department Type Column',   description: 'OPD / IPD / LAB etc.',                         configType: 'COLUMN',       category: 'DEPARTMENT' },
  { key: 'department.col.status',     defaultValue: 'STATUS',            label: 'Status Column',            description: 'Column holding active/inactive flag',          configType: 'COLUMN',       category: 'DEPARTMENT' },
  { key: 'department.status.active',  defaultValue: 'A',                 label: 'Active Status Value',      description: 'Value meaning department is active',           configType: 'STATUS_VALUE', category: 'DEPARTMENT' },

  // ── DOCTOR ────────────────────────────────────────────────────────────────
  { key: 'doctor.table',             defaultValue: 'DOCTOR_MASTER',  label: 'Doctor Table',             description: 'Master list of doctors / consultants',   configType: 'TABLE',        category: 'DOCTOR' },
  { key: 'doctor.col.code',          defaultValue: 'DOCTOR_CODE',    label: 'Doctor Code Column',       description: '',                                       configType: 'COLUMN',       category: 'DOCTOR' },
  { key: 'doctor.col.name',          defaultValue: 'DOCTOR_NAME',    label: 'Doctor Name Column',       description: '',                                       configType: 'COLUMN',       category: 'DOCTOR' },
  { key: 'doctor.col.specialization',defaultValue: 'SPECIALIZATION', label: 'Specialization Column',    description: '',                                       configType: 'COLUMN',       category: 'DOCTOR' },
  { key: 'doctor.col.deptCode',      defaultValue: 'DEPT_CODE',      label: 'Department Code Column',   description: '',                                       configType: 'COLUMN',       category: 'DOCTOR' },
  { key: 'doctor.col.deptName',      defaultValue: 'DEPT_NAME',      label: 'Department Name Column',   description: '',                                       configType: 'COLUMN',       category: 'DOCTOR' },
  { key: 'doctor.col.qualification', defaultValue: 'QUALIFICATION',  label: 'Qualification Column',     description: 'nullable',                               configType: 'COLUMN',       category: 'DOCTOR' },
  { key: 'doctor.col.status',        defaultValue: 'STATUS',         label: 'Status Column',            description: 'Column holding active/inactive flag',    configType: 'COLUMN',       category: 'DOCTOR' },
  { key: 'doctor.status.active',     defaultValue: 'A',              label: 'Active Status Value',      description: 'Value meaning doctor is active',         configType: 'STATUS_VALUE', category: 'DOCTOR' },
];

export const CATEGORY_LABELS: Record<string, string> = {
  PATIENT:    'Patient Master',
  BILLING:    'Billing Header',
  BILL_ITEMS: 'Bill Line Items',
  VISIT:      'Visit / Admission',
  DEPARTMENT: 'Department Master',
  DOCTOR:     'Doctor Master',
};
