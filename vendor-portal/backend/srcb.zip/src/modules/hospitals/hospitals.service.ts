import {
  Injectable, Logger, ConflictException, NotFoundException, BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as crypto from 'crypto';
import { Hospital } from './entities/hospital.entity';
import { LicenseRequest } from './entities/license-request.entity';
import { IssuedLicense } from './entities/issued-license.entity';
import { RevocationEvent } from './entities/revocation-event.entity';
import { HisSchemaConfig } from './entities/his-schema-config.entity';
import { HIS_SCHEMA_DEFAULTS } from './his-schema-defaults';
import { SigningService } from '../signing/signing.service';
import { WebhookService } from '../webhook/webhook.service';

// ── DTOs ─────────────────────────────────────────────────────────────────────
export interface RegisterHospitalDto {
  hospitalName:       string;
  hospitalCode:       string;
  publicIp:           string;
  publicPort:         number;
  webhookUrl:         string;
  machineFingerprint: string;
}

export interface ApproveRequestDto {
  licenseType:    'TRIAL_EXTENSION' | 'MODULE_LICENSE' | 'PERPETUAL';
  modules:        string[];
  maxUsers:       number;
  expiresAt:      string | null;   // ISO string or null for perpetual
  machineLocked:  boolean;
  vendorNotes?:   string;
}

export interface RevokeDto {
  type:         'FULL' | 'MODULE';
  modules?:     string[];          // required when type = MODULE
  reason:       string;
  forceLogout?: boolean;
}

@Injectable()
export class HospitalsService {
  private readonly logger = new Logger(HospitalsService.name);

  constructor(
    @InjectRepository(Hospital)       private readonly hospitalRepo:    Repository<Hospital>,
    @InjectRepository(LicenseRequest) private readonly requestRepo:     Repository<LicenseRequest>,
    @InjectRepository(IssuedLicense)  private readonly licenseRepo:     Repository<IssuedLicense>,
    @InjectRepository(RevocationEvent)  private readonly revocationRepo:  Repository<RevocationEvent>,
    @InjectRepository(HisSchemaConfig)  private readonly hisConfigRepo:   Repository<HisSchemaConfig>,
    private readonly signingService:  SigningService,
    private readonly webhookService:  WebhookService,
  ) {}

  // ── Registration ─────────────────────────────────────────────────────────────

  async register(dto: RegisterHospitalDto): Promise<{ instanceToken: string; webhookSecret: string }> {
    const existing = await this.hospitalRepo.findOne({ where: { hospitalCode: dto.hospitalCode } });
    if (existing) {
      throw new ConflictException(`Hospital code '${dto.hospitalCode}' is already registered`);
    }

    const instanceToken = crypto.randomBytes(32).toString('hex');
    const webhookSecret = crypto.randomBytes(48).toString('hex');

    const hospital = this.hospitalRepo.create({
      instanceToken,
      webhookSecret,
      hospitalName:       dto.hospitalName,
      hospitalCode:       dto.hospitalCode,
      publicIp:           dto.publicIp,
      publicPort:         dto.publicPort,
      webhookUrl:         dto.webhookUrl,
      machineFingerprint: dto.machineFingerprint,
      status:             'ACTIVE',
    });
    await this.hospitalRepo.save(hospital);

    this.logger.log(`Hospital registered: ${dto.hospitalCode} @ ${dto.publicIp}:${dto.publicPort}`);

    // Confirm registration back to hospital via webhook
    await this.webhookService.deliver(hospital, {
      type:          'REGISTRATION_CONFIRMED',
      instanceToken,
      hospitalCode:  dto.hospitalCode,
    });

    return { instanceToken, webhookSecret };
  }

  // ── Hospital CRUD ─────────────────────────────────────────────────────────────

  findAll(): Promise<Hospital[]> {
    return this.hospitalRepo.find({ order: { registeredAt: 'DESC' } });
  }

  async findOne(id: string): Promise<Hospital> {
    const h = await this.hospitalRepo.findOne({
      where: { id },
      relations: ['requests', 'licenses', 'revocations'],
    });
    if (!h) throw new NotFoundException(`Hospital ${id} not found`);
    return h;
  }

  async findByToken(instanceToken: string): Promise<Hospital | null> {
    return this.hospitalRepo.findOne({ where: { instanceToken } });
  }

  async updateNotes(id: string, notes: string): Promise<Hospital> {
    await this.hospitalRepo.update(id, { notes });
    return this.findOne(id);
  }

  async suspend(id: string): Promise<Hospital> {
    await this.hospitalRepo.update(id, { status: 'SUSPENDED' });
    return this.findOne(id);
  }

  async activate(id: string): Promise<Hospital> {
    await this.hospitalRepo.update(id, { status: 'ACTIVE' });
    return this.findOne(id);
  }

  // ── License Requests ──────────────────────────────────────────────────────────

  async createRequest(instanceToken: string, payload: {
    requestedModules: string[];
    currentModules:   string[];
    remarks?:         string;
    machineFingerprint: string;
    isTrial:          boolean;
    expiresAt?:       string | null;
  }): Promise<{ requestId: string }> {
    const hospital = await this.hospitalRepo.findOne({ where: { instanceToken, status: 'ACTIVE' } });
    if (!hospital) throw new BadRequestException('Unknown or suspended instance token');

    const request = this.requestRepo.create({
      hospital,
      hospitalId:         hospital.id,
      requestedModules:   payload.requestedModules,
      currentModules:     payload.currentModules,
      remarks:            payload.remarks ?? null,
      machineFingerprint: payload.machineFingerprint,
      isTrial:            payload.isTrial,
      status:             'PENDING',
    });
    await this.requestRepo.save(request);

    this.logger.log(`License request from ${hospital.hospitalCode}: modules=${payload.requestedModules.join(',')}`);
    return { requestId: request.id };
  }

  findAllRequests(status?: string): Promise<LicenseRequest[]> {
    const where = status ? { status: status as any } : {};
    return this.requestRepo.find({
      where,
      relations: ['hospital'],
      order: { submittedAt: 'DESC' },
    });
  }

  async findRequest(id: string): Promise<LicenseRequest> {
    const r = await this.requestRepo.findOne({ where: { id }, relations: ['hospital'] });
    if (!r) throw new NotFoundException(`Request ${id} not found`);
    return r;
  }

  // ── Approval ──────────────────────────────────────────────────────────────────

  async approveRequest(requestId: string, dto: ApproveRequestDto, issuedById: string): Promise<IssuedLicense> {
    const request = await this.findRequest(requestId);
    if (request.status !== 'PENDING') {
      throw new BadRequestException(`Request is already ${request.status}`);
    }

    const hospital = request.hospital;

    // Build and sign the license payload
    const payload = {
      licenseKey:         crypto.randomUUID(),
      hospitalName:       hospital.hospitalName,
      hospitalCode:       hospital.hospitalCode,
      issuedAt:           new Date().toISOString(),
      expiresAt:          dto.expiresAt ?? null,
      modules:            dto.modules,
      maxUsers:           dto.maxUsers,
      machineFingerprint: dto.machineLocked ? hospital.machineFingerprint : null,
    };

    const signedLicense = this.signingService.sign(payload);

    // Persist issued license
    const issued = this.licenseRepo.create({
      hospital,
      hospitalId:       hospital.id,
      requestId:        requestId,
      licenseType:      dto.licenseType,
      licensedModules:  dto.modules,
      maxUsers:         dto.maxUsers,
      expiresAt:        dto.expiresAt ? new Date(dto.expiresAt) : null,
      machineLocked:    dto.machineLocked,
      status:           'ACTIVE',
      signedPayload:    signedLicense as unknown as Record<string, unknown>,
      issuedBy:         issuedById,
    });
    await this.licenseRepo.save(issued);

    // Update request status
    request.status     = 'APPROVED';
    request.resolvedAt = new Date();
    request.resolvedBy = issuedById;
    if (dto.vendorNotes) request.vendorNotes = dto.vendorNotes;
    await this.requestRepo.save(request);

    // Deliver license to hospital via webhook
    const webhookResult = await this.webhookService.deliver(hospital, {
      type:            'LICENSE_APPROVED',
      vendorRequestId: requestId,
      signedLicense:   signedLicense,
    });

    if (!webhookResult.ok) {
      this.logger.warn(`License issued but webhook delivery failed for ${hospital.hospitalCode}: ${webhookResult.error}`);
    }

    return issued;
  }

  async rejectRequest(requestId: string, reason: string, rejectedById: string): Promise<LicenseRequest> {
    const request = await this.findRequest(requestId);
    if (request.status !== 'PENDING') {
      throw new BadRequestException(`Request is already ${request.status}`);
    }

    request.status          = 'REJECTED';
    request.rejectionReason = reason;
    request.resolvedAt      = new Date();
    request.resolvedBy      = rejectedById;
    await this.requestRepo.save(request);

    // Notify hospital
    await this.webhookService.deliver(request.hospital, {
      type:            'REQUEST_REJECTED',
      vendorRequestId: requestId,
      reason,
    });

    return request;
  }

  // ── Trial Extension ───────────────────────────────────────────────────────────

  async extendTrial(hospitalId: string, newExpiresAt: string, reason: string, issuedById: string): Promise<void> {
    const hospital = await this.findOne(hospitalId);
    await this.webhookService.deliver(hospital, {
      type:        'TRIAL_EXTENDED',
      newExpiresAt,
      reason,
    });
    this.logger.log(`Trial extended for ${hospital.hospitalCode} to ${newExpiresAt}`);
  }

  // ── Revocation ────────────────────────────────────────────────────────────────

  async revokeHospital(hospitalId: string, dto: RevokeDto, revokedById: string): Promise<RevocationEvent> {
    const hospital = await this.findOne(hospitalId);

    if (dto.type === 'MODULE' && (!dto.modules || dto.modules.length === 0)) {
      throw new BadRequestException('modules[] is required for MODULE revocation');
    }

    // Mark all active licenses as revoked
    if (dto.type === 'FULL') {
      await this.licenseRepo.update(
        { hospitalId, status: 'ACTIVE' },
        { status: 'REVOKED', revokedBy: revokedById, revokedAt: new Date(), revokeReason: dto.reason },
      );
    }

    const event = this.revocationRepo.create({
      hospital,
      hospitalId,
      revocationType: dto.type,
      modules:        dto.type === 'MODULE' ? dto.modules! : null,
      reason:         dto.reason,
      forceLogout:    dto.forceLogout ?? false,
      revokedBy:      revokedById,
      webhookStatus:  'PENDING',
    });
    await this.revocationRepo.save(event);

    // Deliver webhook immediately
    const webhookPayload = dto.type === 'FULL'
      ? { type: 'LICENSE_REVOKED',  reason: dto.reason, forceLogout: dto.forceLogout ?? false }
      : { type: 'MODULE_REVOKED',   reason: dto.reason, modules: dto.modules };

    await this.webhookService.deliverRevocation(event.id, hospital, webhookPayload);

    return event;
  }

  // ── Issued Licenses ───────────────────────────────────────────────────────────

  findActiveLicenses(): Promise<IssuedLicense[]> {
    return this.licenseRepo.find({
      where: { status: 'ACTIVE' },
      relations: ['hospital'],
      order: { issuedAt: 'DESC' },
    });
  }

  // All licenses regardless of status — for history view
  findAllLicenses(): Promise<IssuedLicense[]> {
    return this.licenseRepo.find({
      relations: ['hospital'],
      order: { issuedAt: 'DESC' },
    });
  }

  findHospitalLicenses(hospitalId: string): Promise<IssuedLicense[]> {
    return this.licenseRepo.find({
      where: { hospitalId },
      order: { issuedAt: 'DESC' },
    });
  }

  // All revocation events — for transaction log
  findAllRevocations(): Promise<RevocationEvent[]> {
    return this.revocationRepo.find({
      relations: ['hospital'],
      order: { createdAt: 'DESC' },
    });
  }

  // ── HIS Schema Config ────────────────────────────────────────────────────

  /** Return config for a hospital, merging saved values with defaults. */
  async getHisConfig(hospitalId: string): Promise<HisSchemaConfig[]> {
    await this.findOne(hospitalId); // throws 404 if not found

    const saved = await this.hisConfigRepo.find({ where: { hospitalId } });
    const savedMap = new Map(saved.map(r => [r.configKey, r]));

    // Return defaults merged with any saved overrides — upsert missing rows
    const results: HisSchemaConfig[] = [];
    for (const def of HIS_SCHEMA_DEFAULTS) {
      if (savedMap.has(def.key)) {
        results.push(savedMap.get(def.key)!);
      } else {
        // Auto-create with default value so the UI always has a full list
        const row = this.hisConfigRepo.create({
          hospitalId,
          configKey:    def.key,
          configValue:  def.defaultValue,
          defaultValue: def.defaultValue,
          label:        def.label,
          description:  def.description || null,
          configType:   def.configType,
          category:     def.category,
        });
        results.push(await this.hisConfigRepo.save(row));
      }
    }
    return results;
  }

  /** Update one or more config entries. */
  async updateHisConfig(
    hospitalId: string,
    updates: Array<{ configKey: string; configValue: string }>,
  ): Promise<HisSchemaConfig[]> {
    await this.findOne(hospitalId);

    for (const { configKey, configValue } of updates) {
      await this.hisConfigRepo.upsert(
        {
          hospitalId,
          configKey,
          configValue: configValue.trim().toUpperCase(),
          // fill static fields from defaults so upsert doesn't wipe them
          ...(() => {
            const def = HIS_SCHEMA_DEFAULTS.find(d => d.key === configKey);
            return def ? {
              defaultValue: def.defaultValue,
              label:        def.label,
              description:  def.description || null,
              configType:   def.configType,
              category:     def.category,
            } : {};
          })(),
        },
        ['hospitalId', 'configKey'],
      );
    }

    return this.getHisConfig(hospitalId);
  }

  /** Push the saved config to HDSP via webhook. */
  async pushHisConfig(hospitalId: string): Promise<{ ok: boolean; message: string }> {
    const hospital = await this.findOne(hospitalId);
    const config   = await this.getHisConfig(hospitalId);

    const payload: Record<string, string> = {};
    for (const row of config) {
      payload[row.configKey] = row.configValue;
    }

    const result = await this.webhookService.deliver(hospital, {
      type:      'HIS_CONFIG_UPDATE',
      hisConfig: payload,
    });

    if (!result.ok) {
      return { ok: false, message: `Webhook delivery failed: ${result.error}` };
    }
    return { ok: true, message: 'HIS schema config pushed to hospital successfully.' };
  }
}
