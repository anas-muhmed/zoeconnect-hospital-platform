import {
  Injectable, UnauthorizedException, OnModuleInit, Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { JwtService } from '@nestjs/jwt';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { VendorUser } from './entities/vendor-user.entity';

@Injectable()
export class AuthService implements OnModuleInit {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    @InjectRepository(VendorUser) private readonly userRepo: Repository<VendorUser>,
    private readonly jwtService: JwtService,
  ) {}

  /** Seed default admin on first run if no users exist */
  async onModuleInit(): Promise<void> {
    const count = await this.userRepo.count();
    if (count === 0) {
      const hash = await bcrypt.hash(process.env.DEFAULT_ADMIN_PASSWORD ?? 'VendorAdmin@123', 12);
      await this.userRepo.save(this.userRepo.create({
        username:     'admin',
        passwordHash: hash,
        role:         'ADMIN',
      }));
      this.logger.warn('Default admin user created — change password immediately');
    }
  }

  async login(username: string, password: string): Promise<{ accessToken: string; user: Partial<VendorUser> }> {
    const user = await this.userRepo.findOne({ where: { username, isActive: true } });
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const accessToken = this.jwtService.sign({
      sub:      user.id,
      username: user.username,
      role:     user.role,
    });

    return {
      accessToken,
      user: { id: user.id, username: user.username, role: user.role },
    };
  }

  async validateToken(payload: { sub: string }): Promise<VendorUser | null> {
    return this.userRepo.findOne({ where: { id: payload.sub, isActive: true } });
  }

  async changePassword(userId: string, currentPassword: string, newPassword: string): Promise<void> {
    const user = await this.userRepo.findOne({ where: { id: userId } });
    if (!user || !(await bcrypt.compare(currentPassword, user.passwordHash))) {
      throw new UnauthorizedException('Current password is incorrect');
    }
    user.passwordHash = await bcrypt.hash(newPassword, 12);
    await this.userRepo.save(user);
  }
}
