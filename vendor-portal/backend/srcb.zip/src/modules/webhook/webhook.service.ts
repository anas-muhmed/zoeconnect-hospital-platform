import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Hospital } from '../hospitals/entities/hospital.entity';
import { RevocationEvent } from '../hospitals/entities/revocation-event.entity';
import { SigningService } from '../signing/signing.service';

export interface WebhookPayload {
  type: string;
  [key: string]: unknown;
}

@Injectable()
export class WebhookService {
  private readonly logger = new Logger(WebhookService.name);

  constructor(
    @InjectRepository(Hospital)
    private readonly hospitalRepo: Repository<Hospital>,
    @InjectRepository(RevocationEvent)
    private readonly revocationRepo: Repository<RevocationEvent>,
    private readonly signingService: SigningService,
  ) {}

  async deliver(hospital: Hospital, payload: WebhookPayload): Promise<{ ok: boolean; error?: string }> {
    const body = JSON.stringify(payload);
    const signature = this.signingService.computeHmac(hospital.webhookSecret, body);

    try {
      const res = await fetch(hospital.webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type':       'application/json',
          'X-Vendor-Signature': signature,
        },
        body,
        signal: AbortSignal.timeout(15_000),
      });

      const ok = res.ok;
      await this.hospitalRepo.update(hospital.id, {
        lastWebhookAt:     new Date(),
        lastWebhookStatus: ok ? 'OK' : 'FAILED',
      });

      if (!ok) {
        const errText = await res.text();
        this.logger.warn(`Webhook to ${hospital.hospitalCode} failed (${res.status}): ${errText}`);
        return { ok: false, error: `HTTP ${res.status}: ${errText}` };
      }

      this.logger.log(`Webhook delivered to ${hospital.hospitalCode}: type=${payload.type}`);
      return { ok: true };
    } catch (err: any) {
      await this.hospitalRepo.update(hospital.id, {
        lastWebhookAt:     new Date(),
        lastWebhookStatus: 'FAILED',
      });
      this.logger.error(`Webhook delivery failed for ${hospital.hospitalCode}: ${err.message}`);
      return { ok: false, error: err.message };
    }
  }

  async deliverRevocation(
    revocationId: string,
    hospital: Hospital,
    payload: WebhookPayload,
  ): Promise<void> {
    const result = await this.deliver(hospital, payload);
    await this.revocationRepo.update(revocationId, {
      webhookStatus: result.ok ? 'DELIVERED' : 'FAILED',
    });
  }
}
