import { DataSource } from 'typeorm';
import { Hospital }         from '../modules/hospitals/entities/hospital.entity';
import { LicenseRequest }   from '../modules/hospitals/entities/license-request.entity';
import { IssuedLicense }    from '../modules/hospitals/entities/issued-license.entity';
import { RevocationEvent }  from '../modules/hospitals/entities/revocation-event.entity';
import { VendorUser }       from '../modules/auth/entities/vendor-user.entity';

export const AppDataSource = new DataSource({
  type:        'postgres',
  host:        process.env.DB_HOST     ?? 'localhost',
  port:        parseInt(process.env.DB_PORT ?? '5433'),
  username:    process.env.DB_USER     ?? 'vendor_app',
  password:    process.env.DB_PASS     ?? 'vendor_secret',
  database:    process.env.DB_NAME     ?? 'vendor_db',
  synchronize: false,
  logging:     process.env.NODE_ENV === 'development',
  entities:    [Hospital, LicenseRequest, IssuedLicense, RevocationEvent, VendorUser],
  migrations:  [__dirname + '/../database/migrations/*.{ts,js}'],
});
