import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Hospital }        from './modules/hospitals/entities/hospital.entity';
import { LicenseRequest }  from './modules/hospitals/entities/license-request.entity';
import { IssuedLicense }   from './modules/hospitals/entities/issued-license.entity';
import { RevocationEvent }  from './modules/hospitals/entities/revocation-event.entity';
import { HisSchemaConfig }  from './modules/hospitals/entities/his-schema-config.entity';
import { VendorUser }       from './modules/auth/entities/vendor-user.entity';
import { AuthModule }      from './modules/auth/auth.module';
import { HospitalsModule } from './modules/hospitals/hospitals.module';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type:        'postgres',
      host:        process.env.DB_HOST     ?? 'localhost',
      port:        parseInt(process.env.DB_PORT ?? '5433'),
      username:    process.env.DB_USER     ?? 'vendor_app',
      password:    process.env.DB_PASS     ?? 'vendor_secret',
      database:    process.env.DB_NAME     ?? 'vendor_db',
      synchronize: process.env.NODE_ENV === 'development',   // migrations in production
      logging:     process.env.NODE_ENV === 'development',
      entities:    [Hospital, LicenseRequest, IssuedLicense, RevocationEvent, HisSchemaConfig, VendorUser],
    }),
    AuthModule,
    HospitalsModule,
  ],
})
export class AppModule {}
